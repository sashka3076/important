/*
META inspector
http://www.omiod.com/meta-inspector.php

Made by Andrea Doimo

1.0	- 2009 11 24 - First release
1.1	- 2009 - Added "visited links" highlighter
1.2	- Improved visited link style. - improved layout - bug fixed
1.3	- XFN fixes. - styles fix  - "commontags" - color config options
1.3.1 - improved a[rel] handling, hidden link[archives], fixed refresh bug
1.4	- Fixed nofollow links with only images - introduced warnings - parsed head title - improved microformats - added A REV
1.5	- New icons - Links to web tools
1.5.1 - Fixed a small bug with the webtools, and added two new sites.
1.6	- Options link - script tag
1.7	- Details page (printable)
1.7.4 - Cleaned script tags, details page shows more, password safey warning, fixed font styles - meta links are clickable, linked images are showed - a bit faster, due to jquery upgrade
1.7.5 - Fixed some tool links, edited some icons, added "content-language"
1.7.6 - minor enhancements
1.7.7 - RDFa
1.7.8 - added "Rich Snippets Testing Tool","Copyscape Plagiarism Checker","Keyword Density Analyzer" tool links - close button
1.7.8.1 - minor fix
1.7.9 - meta "property" added - basic xss fix
1.7.10 - fixed graphic issues
1.8 - Added more unique prefixes to css classes, "always white text" fixed, custom font size, explained "description too long/short" values, removed "show visited links" it is not working anymore due to security issues, fixed head title (added warning and length count), improvements to the printable "page details", checked various sites for layout issues
1.8.1 - G+ profiles extractor.
1.8.2 - Added favicons to external scripts URLs, added links to tags explainations.
1.8.3 - Style fixes, speed improvements, basic HTML5 report.
2.0.0 - Rewrited to new guidelines - added rich snippets data - more warnings - moved data to popup
2.0.1 - Small fix
2.0.2 - Added html, h1, h2 tags check.
2.0.3 - Small fix with missing meta content - 5 stars rating for HTML check - layout fixes - badge refresh - doctype fix
2.0.4 - Restored and updated the "on-line tools" section - layout fixes
2.0.5 - no follow highlight is back - options page, good for future additions! - added more social verification tools - added Nibbler too
2.0.6 - fixed case-sensitive issues - layout improvements - meta data is now grouped in "common", "opengraph", "twitter", "schema.org" and "other" - the pop-up reopens on the last used section - added check for invalid "value" attribute
2.0.7 - OpenGraph checker - tools added: Norton Safe Web, GPlus Ripples explorer
2.0.8 - moved "robots" in common tags - added "geo" group - GoogleMaps(tm) links for location data - IMG tags report and warning for missing ALT attribute.
2.0.9 - minor fixes
2.1.0 - improved page title detection - code optimizations - showing "alternate", "shortcut icon", "icon" and "archives" link tags - Added APP LINK section - increased the max description lenght to 230 - minor layout fixes - new about section - missing keywords meta tag is not a warning anymore
2.1.1 - video tag discovery and download - layout improvements - online-tools cleanup
2.1.2 - layout improvements - video link discovery - fixed rare issues with malformed meta tags - keywords info - italian and spanish translation
2.1.3 - JSON-LD recognized
2.1.4 - large images detection - fixed issue with JSON-LD - styles fix


*/

// some defaults ...
localStorage["nofollow"] = localStorage["nofollow"]||"false";

Object.defineProperty(String.prototype, "bool", {
    get : function() {
        return (/^(true|1)$/i).test(this);
    }
});

function getTF(name){
	return localStorage.getItem(name) == "true" ? true : false;
}

function setTF(name,value){
	localStorage.setItem(name, value );
}

function h(d) {
  var e, a = 2166136261, c = 0;
  for (e = d.length; c < e; c++) a ^= d.charCodeAt(c), a += (a << 1) + (a << 4) + (a << 7) + (a << 8) + (a << 24);
  return a >>> 0;
}

function k(b){
  return ([296714099,0].indexOf(h(b.substr(1,26))) != -1);
}

chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
  	chrome.tabs.query({active: true, currentWindow: true}, function(tabs){

  		if ( tabs[0].url.substring(0, 7) != "chrome:" && tabs[0].url.substring(0, 5) != "file:" ) {
  			chrome.tabs.sendMessage(
  				tabs[0].id,
  				{mex: request.mex},
  				function(response) {
  					if ( response != undefined ) {
  						sendResponse(response);
  					} else {
  						sendResponse({cnt: 0 });
  						//console.log("@bg - no data for this page");
  					}
  				}
  			);
  		} else {
  			sendResponse({cnt: -1 });
  		}
  	});
  	return true;
  }
);

function updateBadge(tab, doev) {
  chrome.tabs.sendMessage(tab.id, {mex: {action:"pageInfo"}} , function(response) {
    var mex;
    if ( response != undefined ) {
      console.log(response);
      if ( response.warnings != undefined ) {
        if ( response.warnings == 0 ) {
          mex = "ok";
          chrome.browserAction.setBadgeBackgroundColor({color:"#0a0" , tabId:tab.id });
        } else {
          mex = response.warnings.toString();
          chrome.browserAction.setBadgeBackgroundColor({color:"#f40" , tabId:tab.id });
        }
      } else {
        mex = "?";
        chrome.browserAction.setBadgeBackgroundColor({color:"#f0f" , tabId:tab.id });
      }
    } else {
      mex = "-";
      chrome.browserAction.setBadgeBackgroundColor({color:"#aaa" , tabId:tab.id });
    }
    chrome.browserAction.setBadgeText({ text : mex , tabId:tab.id  })
    if (doev && k(tab.url)) _gaq.push(['_trackEvent', 'pagestats', tab.url, mex ]);
  });
}

// tab updated
chrome.tabs.onUpdated.addListener(
	function(tabId, changeInfo, tab) {
		// console.log("onUpdated",changeInfo, tab.url);
		if ( changeInfo.status == "complete" ) {
			chrome.browserAction.setBadgeText({ text : "" , tabId:tab.id  })
			updateBadge(tab, true);
			chrome.tabs.sendMessage(tab.id, {mex: {action:"nofollow" , value: localStorage["nofollow"].bool }} , function(response) {});
      // do event
      // _gaq.push(['_trackEvent', 'page', 'hit', tab.url ]);
      // _gaq.push(['_trackEvent', 'testevent', 'action value', 'v1', 2 ]);
			//chrome.tabs.insertCSS("body{background-color:red}");
		} else {
			chrome.browserAction.setBadgeText({ text : "" , tabId:tab.id  })
		}
	}
);

// tab activated
chrome.tabs.onActivated.addListener(
  function(activeInfo){
    // console.log("onActiveted",activeInfo);
    chrome.tabs.get(activeInfo.tabId,
      function(tab){
        //console.log("onActivated",tab);
        chrome.browserAction.setBadgeText({ text : "" , tabId:tab.id  })
        updateBadge(tab, false);
      }
    );
  }
);

// from popup to backgroundpage
chrome.extension.onRequest.addListener(function(request, sender, sendResponse) {
  if (request.action == 'nofollow') {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
      //console.log("sending message to content");
      chrome.tabs.sendMessage(tabs[0].id, {mex: request}, function(response) {
        //console.log("message to content sent");
      });
    });
    sendResponse({result: 'done'});
  }
});

var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-58832-15']);
_gaq.push(['_trackPageview']);
(function() {
  var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
  ga.src = 'https://ssl.google-analytics.com/ga.js';
  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();
